#include "aht_sgp.h"
#include "../include/pins.h"
#include <Wire.h>
#include <Adafruit_AHTX0.h>
#include <Adafruit_SGP40.h>

// ============================================
// I2C SENSOREN IMPLEMENTATION
// ============================================

static Adafruit_AHTX0 aht;
static Adafruit_SGP40 sgp;

bool sensors_i2c_init(void) {
  // I2C Bus initialisieren
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  delay(500);

  // AHT20 initialisieren
  bool ahtOK = aht.begin();
  Serial.printf("  AHT20: %s\n", ahtOK ? "OK" : "FEHLER");

  // SGP40 initialisieren
  bool sgpOK = sgp.begin();
  Serial.printf("  SGP40: %s\n", sgpOK ? "OK" : "FEHLER");

  return ahtOK && sgpOK;
}

bool sensors_aht20_read(AHT20_Data* data) {
  if (!data) return false;

  sensors_event_t humidity, temp;
  aht.getEvent(&humidity, &temp);

  data->temperature = temp.temperature;
  data->humidity = humidity.relative_humidity;

  return true;
}

bool sensors_sgp40_read(float temperature, float humidity, SGP40_Data* data) {
  if (!data) return false;

  int32_t vocIndex = sgp.measureVocIndex(temperature, humidity);
  data->voc_index = vocIndex;

  return true;
}
